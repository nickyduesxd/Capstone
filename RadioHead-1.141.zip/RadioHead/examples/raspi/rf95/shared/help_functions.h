// -*- mode: C++ -*-
/*
 * help_functions.h
 *
 *  Created on: Jun 11, 2020
 *      Author: Tilman Glötzner
 */

#ifndef HELP_FUNCTIONS_H_
#define HELP_FUNCTIONS_H_
void print_scheduler(void);
void print_scope(void);
#endif
